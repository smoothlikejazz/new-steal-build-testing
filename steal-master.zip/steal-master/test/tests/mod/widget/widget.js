steal(function(){
	return function(){
		return "widget"
	};
});
