steal(function(){
	return {
		name: "bar"
	};
});
