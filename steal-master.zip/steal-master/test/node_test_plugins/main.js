define(["template.plug!plug"], function(template){
	global.PLUGTEXT = template();
	console.log(template())
});


