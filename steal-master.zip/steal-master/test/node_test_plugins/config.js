System.map["plugin-dep"] = "plugin-client-dep";

System.buildConfig = {
	map: {
		"plugin-dep": "plugin-server-dep"
	}
};
