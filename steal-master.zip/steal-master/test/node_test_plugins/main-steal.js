steal("template.plug!plug", function(template){
	window.PLUGTEXT = template();
});
