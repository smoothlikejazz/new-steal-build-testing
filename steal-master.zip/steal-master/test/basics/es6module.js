import amdMod from 'basics/amdmodule';

export default {
	amdModule: amdMod,
	name: "es6Module"
};
