steal(function(){
	return {name: "pathed"};
});
