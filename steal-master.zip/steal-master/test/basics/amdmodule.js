define(function(){
	return {
		name: "amdmodule"
	};
});
