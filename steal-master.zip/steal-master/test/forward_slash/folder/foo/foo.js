export var bar = "baz";
