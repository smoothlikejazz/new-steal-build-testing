steal("./other.js", function(other) {
	 return {
		other: other
	 };
});
