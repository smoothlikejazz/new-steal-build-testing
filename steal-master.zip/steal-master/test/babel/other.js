var foo = "bar";

export default foo;
