window.main2 = true;
