@typedef {Object} @traceur
@parent StealJS.modules

@option {Object} 
The [traceur compiler](https://github.com/google/traceur-compiler) which
is used to convert ES6 to ES5.  The defaut path to `@traceur` is specified in
[System.paths].
